// ============================================================
// DRAW + UPDATE - gamedrawcreate.js
// ============================================================
console.log('🎨 Bắt đầu load gamedrawcreate.js...');

// ⭐ CAMERA ZOOM STATE
window.cameraZoom = 1.0;
window.smoothCameraEnabled = true;

// ============================================================
// CACHE ẢNH SCALED
// ============================================================
const scaledWeaponCache = {};

function getScaledSprite(sprite, scale) {
    const key = sprite.src + '_' + scale;
    if (!scaledWeaponCache[key]) {
        const c = document.createElement('canvas');
        c.width = sprite.width * scale;
        c.height = sprite.height * scale;
        const cx = c.getContext('2d');
        cx.imageSmoothingEnabled = false;
        cx.drawImage(sprite, 0, 0, c.width, c.height);
        scaledWeaponCache[key] = c;
    }
    return scaledWeaponCache[key];
}

// ============================================================
// CAMERA ZOOM HANDLING
// ============================================================
window.updateCameraZoom = function(zoom) {
    window.cameraZoom = Math.max(0.5, Math.min(2, zoom));
    console.log('📷 Camera zoom:', window.cameraZoom);
};

window.applyCameraTransform = function() {
    const zoom = window.cameraZoom || 1;
    ctx.setTransform(devicePixelRatio * zoom, 0, 0, devicePixelRatio * zoom, 0, 0);
};

// ============================================================
// VẼ SÚNG
// ============================================================
function drawWeapon(c, px, py) {
    if (typeof inventory === 'undefined') return;
    if (typeof weaponSprites === 'undefined') return;
    if (typeof Hand === 'undefined') return;
    if (typeof Camera === 'undefined') return;
    
    const item = inventory[selectedSlot];
    if (!item || item.type === 'material' || item.type === 'consumable') return;
    
    // ⭐ LẤY VỊ TRÍ TAY
    const hand = Hand.getPosition();
    const screenX = hand.x - Camera.x;
    const screenY = hand.y - Camera.y;
    
    let sprite = null, scale = 3;
    
    switch (item.id) {
        case 'pistol': sprite = weaponSprites.pistol; scale = 3.5; break;
        case 'rifle': sprite = weaponSprites.rifle; scale = 3; break;
        case 'awp':
        case 'barret':
        case 'railgun': sprite = weaponSprites.sniper; scale = 3; break;
        case 'plasma': sprite = weaponSprites.plasma; scale = 3; break;
        case 'shotgun': sprite = weaponSprites.shotgun; scale = 3; break;
        case 'collapsed_scythe': sprite = weaponSprites.scythe; scale = 0.3; break;
        default: return;
    }
    
    // ⭐ VẼ BÀN TAY
    c.save();
    c.translate(screenX, screenY);
    
    // Bàn tay tròn
    c.fillStyle = '#f4a460';
    c.strokeStyle = '#8b4513';
    c.lineWidth = 3;
    c.beginPath();
    c.arc(0, 0, 10, 0, Math.PI * 2);
    c.fill();
    c.stroke();
    
    // ⭐ VẼ VŨ KHÍ (LẬT THEO JOYSTICK, KHÔNG THEO TAY)
    if (sprite && sprite.complete && sprite.naturalWidth > 0) {
        const cached = getScaledSprite(sprite, scale);
        
        // ⭐ KHÓA LẬT THEO FIREJOY (không theo Hand)
        let lockAngle = hand.angle;
        if (typeof fireJoy !== 'undefined' && fireJoy.active) {
            lockAngle = fireJoy.angle;
        }
        
        const shouldFlip = Math.abs(lockAngle) > Math.PI / 2;
        
        c.save();
        if (shouldFlip) {
            c.scale(1, -1);
            c.rotate(-hand.angle);
        } else {
            c.rotate(hand.angle);
        }
        c.drawImage(cached, 12, -cached.height / 2);
        c.restore();
    }
    
    c.restore();
}
// ============================================================
// VẼ GAME
// ============================================================
window.drawGame = function() {
    if (typeof ctx === 'undefined') return;
    if (typeof W === 'undefined' || W === 0) return;
    
    // Apply camera zoom transform
    if (typeof window.applyCameraTransform === 'function') {
        window.applyCameraTransform();
    } else {
        // Fallback
        ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
    }
    
    // Screen effects
    if (typeof applyScreenEffects === 'function') applyScreenEffects();
    
    // Clear (account for zoom)
    const zoom = window.cameraZoom || 1;
    ctx.clearRect(0, 0, W / zoom, H / zoom);
    
    // ⭐ MAP
    if (typeof drawMapBase === 'function') drawMapBase();

    // 🌀 CỔNG DỊCH CHUYỂN (map 2)
    if (typeof drawMapPortal === 'function') drawMapPortal();
// ============================================================
// 🟣 VẼ ORB DECADE
// ============================================================

if (
    typeof orbDecadeActive !== 'undefined' &&
    orbDecadeActive &&
    currentMap === 1
) {
    const s = Camera.toScreen(
        ORB_DECADE.x,
        ORB_DECADE.y
    );

    const pulse = Math.sin(Date.now() * 0.005) * 5;

    ctx.save();

    // Hào quang
    const glow = ctx.createRadialGradient(
        s.x,
        s.y,
        5,
        s.x,
        s.y,
        65 + pulse
    );

    glow.addColorStop(
        0,
        'rgba(255,255,255,0.9)'
    );

    glow.addColorStop(
        0.25,
        'rgba(190,80,255,0.65)'
    );

    glow.addColorStop(
        0.65,
        'rgba(120,30,255,0.25)'
    );

    glow.addColorStop(
        1,
        'rgba(100,0,180,0)'
    );

    ctx.fillStyle = glow;

    ctx.beginPath();

    ctx.arc(
        s.x,
        s.y,
        65 + pulse,
        0,
        Math.PI * 2
    );

    ctx.fill();

    // Orb
    ctx.fillStyle = '#8b2cff';

    ctx.strokeStyle = '#f0c8ff';

    ctx.lineWidth = 4;

    ctx.beginPath();

    ctx.arc(
        s.x,
        s.y,
        ORB_DECADE.radius,
        0,
        Math.PI * 2
    );

    ctx.fill();
    ctx.stroke();

    // Lõi sáng
    ctx.fillStyle = '#ffffff';

    ctx.beginPath();

    ctx.arc(
        s.x - 9,
        s.y - 10,
        8,
        0,
        Math.PI * 2
    );

    ctx.fill();

    ctx.restore();
}
    
    // Đạn
    if (typeof drawBullets === 'function') drawBullets();
    
    // NPC
    if (typeof drawNPCs === 'function') drawNPCs();
    
    // Nhân vật
    // Nhân vật
if (typeof player !== 'undefined' && typeof Camera !== 'undefined') {
    const ox = player.x, oy = player.y;
    player.x -= Camera.x;
    player.y -= Camera.y;
    player.draw(ctx);
    player.x = ox;
    player.y = oy;
    
    // ⭐ GỌI RIÊNG SAU KHI PHỤC HỒI
    if (typeof drawWeapon === 'function') {
        try { drawWeapon(ctx); } catch(e) {}
    }
}
    
    // Quái
    if (typeof drawMonsters === 'function') drawMonsters();
    
    // Boss
    if (typeof drawBoss === 'function') drawBoss();
    if (typeof drawBossBullets === 'function') drawBossBullets();
    
    // Items
    if (typeof drawDroppedItems === 'function') drawDroppedItems();
    if (typeof drawExplosionEffects === 'function') drawExplosionEffects();
    
    // Aim line
    if (typeof window.drawAimLine === 'function') window.drawAimLine();
    
    // ⭐ TÁN CÂY
    if (typeof drawMapCanopy === 'function') drawMapCanopy();
  // ⭐ VẼ KHỐI 4D
if (typeof hypercube !== 'undefined') hypercube.draw();
  // ⭐ VẼ VỆT CHÉM (ĐÈ LÊN TRÊN)
if (typeof drawSlashTrails === 'function') {
    drawSlashTrails(ctx, player.x - Camera.x, player.y - Camera.y);
}

  // ⭐ VẼ SỐ MÁU BỊ TRỪ (ĐÈ LÊN TRÊN)
if (typeof drawDamageNumbers === 'function') {
    drawDamageNumbers();
}

// 🌀 HIỆU ỨNG CHUYỂN MAP (vẽ trên cùng, đè lên mọi thứ)
if (typeof drawMapTransition === 'function') drawMapTransition();
};

// ============================================================
// N8N WEBHOOK SYNC
// ============================================================
const N8N_WEBHOOK_URL = 'http://localhost:5678/workflow/VQNDvgMz0CIgerTu'; // ⚠️ THAY BẰNG URL N8N THỰC

async function syncToN8n(saveData, action = 'save') {
    if (!userProfile || !userProfile.id) {
        console.log('📡 N8N: Chưa đăng nhập Google, bỏ qua sync');
        return;
    }
    
    const payload = {
        action: action,
        timestamp: Date.now(),
        user: {
            id: userProfile.id,
            email: userProfile.email,
            name: userProfile.name,
            picture: userProfile.picture
        },
        saveSlot: window.currentSaveSlot,
        character: {
            name: userProfile.name,
            level: saveData.player?.level || 1,
            exp: saveData.player?.exp || 0,
            hp: saveData.player?.hp || 200,
            maxHp: saveData.player?.maxHp || 200,
            mp: saveData.player?.mp || 200,
            maxMp: saveData.player?.maxMp || 200,
            coins: saveData.player?.coins || 0,
            currentMap: saveData.currentMap || 1
        },
        stats: {
            playTime: (saveData.lastPlayed || Date.now()) - (saveData.createdAt || Date.now()),
            killCount: saveData.killCount || 0
        },
        inventory: saveData.inventory?.map(item => item ? {
            id: item.id,
            name: item.name,
            count: item.count || 1,
            level: item.weaponLevel || 0,
            damage: item.damage || 0
        } : null).filter(Boolean) || [],
        hotbar: saveData.hotbar?.map(item => item ? {
            id: item.id,
            name: item.name,
            count: item.count || 1,
            level: item.weaponLevel || 0,
            damage: item.damage || 0
        } : null).filter(Boolean) || []
    };
    
    try {
        const response = await fetch(N8N_WEBHOOK_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });
        
        if (response.ok) {
            console.log('📡 N8N: Sync thành công', action);
            if (typeof showNotification === 'function' && action === 'save') {
                showNotification('☁️ Đã đồng bộ lên server!');
            }
        } else {
            console.warn('📡 N8N: Sync thất bại', response.status, response.statusText);
        }
    } catch (error) {
        console.error('📡 N8N: Lỗi kết nối', error);
    }
}

// Make it globally accessible for manual trigger
window.syncToN8n = syncToN8n;
window.collectGameState = collectGameState;
function collectGameState() {
    if (typeof player === 'undefined') return null;
    
    return {
        savedAt: Date.now(),
        player: {
            x: player.x,
            y: player.y,
            hp: player.hp,
            maxHp: player.maxHp,
            mp: player.mp,
            maxMp: player.maxMp,
            coins: player.coins,
            level: player.level,
            exp: player.exp,
            expToNext: player.expToNext
        },
        inventory: inventory ? [...inventory] : [],
        hotbar: inventory ? inventory.slice(0, 6) : [],
        selectedSlot: selectedSlot || 0,
        currentMap: currentMap || 1,
        killCount: killCount || 0
    };
}

window.saveGame = function() {
    if (!window.currentSaveSlot && window.currentSaveSlot !== 0) {
        console.warn('No save slot selected');
        if (typeof showNotification === 'function') showNotification('❌ Chưa chọn slot lưu!');
        return;
    }
    
    const saveData = collectGameState();
    if (!saveData) return;
    
    const key = 'gameSave_' + (userProfile?.id || 'local') + '_' + window.currentSaveSlot;
    const fullSave = {
        ...loadSaveData(window.currentSaveSlot),
        ...saveData,
        lastPlayed: Date.now()
    };
    
    // ⭐ BƯỚC 1: LƯU LOCALSTORAGE TRƯỚC (không thể fail)
    try {
        localStorage.setItem(key, JSON.stringify(fullSave));
        console.log('💾 Đã lưu localStorage:', key);
        if (typeof showNotification === 'function') {
            showNotification('💾 Đã lưu game!');
        }
    } catch (e) {
        console.error('❌ Lỗi lưu localStorage:', e);
        if (typeof showNotification === 'function') {
            showNotification('❌ Lỗi lưu: ' + e.message);
        }
        return;
    }
    
    // ⭐ BƯỚC 2: SYNC N8N SAU (async, không block)
    if (typeof syncToN8n === 'function') {
        syncToN8n(fullSave, 'save').catch(err => {
            console.warn('⚠️ Sync n8n thất bại (không ảnh hưởng save local):', err);
        });
    }
};

window.exportSave = function() {
    const saveData = collectGameState();
    if (!saveData) return;
    
    const exportData = {
        version: '1.0',
        exportDate: new Date().toISOString(),
        user: userProfile ? { name: userProfile.name, email: userProfile.email } : { name: 'Local', email: '' },
        saveSlot: window.currentSaveSlot,
        data: saveData
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'game_save_' + Date.now() + '.json';
    a.click();
    URL.revokeObjectURL(url);
    
    if (typeof showNotification === 'function') showNotification('📤 Đã xuất save file!');
};

window.importSave = function(data) {
    if (!data || !data.data) {
        if (typeof showNotification === 'function') showNotification('❌ Dữ liệu save không hợp lệ!');
        return;
    }
    
    // Apply imported data
    applySaveData(data.data);
    
    // Save to current slot
    if (window.currentSaveSlot !== null && window.currentSaveSlot !== undefined) {
        const key = 'gameSave_' + (userProfile?.id || 'local') + '_' + window.currentSaveSlot;
        localStorage.setItem(key, JSON.stringify({
            ...loadSaveData(window.currentSaveSlot),
            ...data.data,
            lastPlayed: Date.now()
        }));
    }
    
    if (typeof showNotification === 'function') showNotification('📥 Đã nhập save!');
};

window.resetGame = function() {
    // Clear all save slots for current user
    const userId = userProfile?.id || 'local';
    for (let i = 0; i < 3; i++) {
        localStorage.removeItem('gameSave_' + userId + '_' + i);
    }
    
    // Reset game state
    if (typeof player !== 'undefined') player.init();
    if (typeof inventory !== 'undefined') {
        inventory.fill(null);
        if (typeof initInventoryUI === 'function') initInventoryUI();
    }
    
    // Reset globals
    window.currentSaveSlot = null;
    window.currentSaveData = null;
    
    // Reload menu
    location.reload();
};

// Helper to load save data (also used by gamemenu)
function loadSaveData(slotIndex) {
    const userId = userProfile?.id || 'local';
    const key = 'gameSave_' + userId + '_' + slotIndex;
    const data = localStorage.getItem(key);
    
    if (data) {
        try {
            return JSON.parse(data);
        } catch (e) {
            console.error('Parse save data error:', e);
        }
    }
    return null;
}

window.loadGame = function(slotIndex) {
    const saveData = loadSaveData(slotIndex);
    if (saveData) {
        applySaveData(saveData);
        return true;
    }
    return false;
};

function applySaveData(saveData) {
    if (!saveData) return;
    
    // Restore player state
    if (typeof player !== 'undefined' && saveData.player) {
        player.x = saveData.player.x;
        player.y = saveData.player.y;
        player.hp = saveData.player.hp;
        player.maxHp = saveData.player.maxHp;
        player.mp = saveData.player.mp;
        player.maxMp = saveData.player.maxMp;
        player.coins = saveData.player.coins;
        player.level = saveData.player.level;
        player.exp = saveData.player.exp;
        player.expToNext = saveData.player.expToNext;
        player.updateMaxStats();
    }
    
    // Restore inventory
    if (saveData.inventory && typeof inventory !== 'undefined') {
        inventory.length = 0;
        inventory.push(...saveData.inventory);
        if (typeof initInventoryUI === 'function') initInventoryUI();
    }
    
    // Restore selected slot
    if (saveData.selectedSlot !== undefined) {
        selectedSlot = saveData.selectedSlot;
        if (typeof updateHotbarUI === 'function') updateHotbarUI();
    }
    
    // Restore map
    if (saveData.currentMap && typeof enterMap === 'function') {
        enterMap(saveData.currentMap);
    }
    
    // Restore kill count
    if (saveData.killCount !== undefined) killCount = saveData.killCount;
    
    if (typeof UI !== 'undefined') UI.update();
    console.log('📂 Applied save data:', saveData);
}

// Make loadSaveData globally accessible for gamemenu
window.loadSaveData = loadSaveData;

// ============================================================
// UPDATE GAME
// ============================================================
window.updateGame = function() {
    if (typeof moveJoy === 'undefined') return;
    if (typeof player === 'undefined') return;
    if (typeof Camera === 'undefined') return;
    if (typeof MAP === 'undefined') return;
    
    // ⭐ Đóng băng di chuyển khi đang chuyển map
    const frozen = (typeof MapTransition !== 'undefined') && MapTransition.active;

    // Di chuyển
    const dir = frozen ? { x: 0, y: 0 } : moveJoy.getDir();
    if (dir.x !== 0 || dir.y !== 0) {
        const nx = player.x + dir.x * player.speed;
        const ny = player.y + dir.y * player.speed;
        const half = player.size / 2;
        
        if (MAP.isWalkable(nx + half, player.y - half) &&
            MAP.isWalkable(nx + half, player.y + half) &&
            MAP.isWalkable(nx - half, player.y - half) &&
            MAP.isWalkable(nx - half, player.y + half)) {
            player.x = nx;
        }
        if (MAP.isWalkable(player.x + half, ny - half) &&
            MAP.isWalkable(player.x + half, ny + half) &&
            MAP.isWalkable(player.x - half, ny - half) &&
            MAP.isWalkable(player.x - half, ny + half)) {
            player.y = ny;
        }
    }
    
    const half = player.size / 2;
    player.x = Math.max(half, Math.min(MAP.getWidth() - half, player.x));
    player.y = Math.max(half, Math.min(MAP.getHeight() - half, player.y));
    
    // ⭐ Cứu hộ: nếu lọt vào ô đá thì đẩy ra chỗ trống gần nhất
    if (typeof MAP.findFreeSpot === 'function' && !MAP.isWalkable(player.x, player.y)) {
        const free = MAP.findFreeSpot(player.x, player.y);
        player.x = free.x;
        player.y = free.y;
    }

    Camera.follow(player.x, player.y);
    
    // Bắn tự động
    if (typeof fireJoy !== 'undefined' && fireJoy.shouldFire && fireJoy.shouldFire()) {
        const item = (typeof inventory !== 'undefined' && typeof selectedSlot !== 'undefined') 
            ? inventory[selectedSlot] : null;
        if (item && typeof fireByWeapon === 'function') {
            const type = typeof getWeaponType === 'function' ? getWeaponType(item) : 'auto';
            fireByWeapon(fireJoy.getAngle(), type, item.damage, item);
        } else if (typeof fireAutoBullet === 'function') {
            fireAutoBullet(fireJoy.getAngle(), 15);
        }
    }
    
    if (typeof updateBullets === 'function') updateBullets();
    if (typeof updateMonsters === 'function') updateMonsters();
    if (typeof updateBoss === 'function') updateBoss();
    if (typeof updateBossBullets === 'function') updateBossBullets();
    if (typeof updateDroppedItems === 'function') updateDroppedItems();
    if (typeof updateExplosionEffects === 'function') updateExplosionEffects();
    if (typeof updateNPCSystem === 'function') updateNPCSystem();
    
if (typeof UI !== 'undefined') UI.update();
  // ⭐ KHỐI 4D
if (typeof hypercube !== 'undefined') hypercube.update();
  // ⭐ CẬP NHẬT BÀN TAY
if (typeof Hand !== 'undefined' && Hand.update) Hand.update();

  // ⭐ CẬP NHẬT VỆT CHÉM
if (typeof updateSlashTrails === 'function') {
    updateSlashTrails();
}

  // ⭐ CẬP NHẬT SỐ MÁU BỊ TRỪ
if (typeof updateDamageNumbers === 'function') {
    updateDamageNumbers();
}

// 🌀 HIỆU ỨNG CHUYỂN MAP
if (typeof updateMapTransition === 'function') updateMapTransition();

// 🗺️ HỆ THỐNG CỦA MAP (cổng dịch chuyển, vùng boss, orb)
if (typeof updateMapSystems === 'function') updateMapSystems();
};


// ============================================================
// ⭐ BÁO GAME READY
// ============================================================
window._gameReady = true;
console.log('🎨 gamedrawcreate.js sẵn sàng! — GAME READY');